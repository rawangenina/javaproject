import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Rectangle class the second player team
 *
 * @author  Rawan Genina, 000747273
 */
public class Rectangle extends GeometricObject {

    /**
     * Constructor for Rectangle
     *
     * @param x
     * @param y
     * @param fillcolor
     * @param i
     */
    public Rectangle(double x, double y, Color fillcolor, int i) {
        super(x, y, fillcolor);

    }

    /**
     * Draw method for Rectangle
     *
     * @param gc
     */
    @Override
    public void draw(GraphicsContext gc) {
        gc.setFill(getFillColor());
        gc.fillRect(getX() - 24, getY() - 24, 40, 60);

    }

}


