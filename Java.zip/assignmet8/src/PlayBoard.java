import javafx.scene.canvas.GraphicsContext;
import java.awt.Dimension;

/**
 * the bord game
 *  @author  Rawan Genina, 000747273
 */

public abstract class PlayBoard {


    /**
     * Where the actual board contents get stored.
     * Allows for any X by y grid board
     */
    protected int cells[][];

    /**
     * used for temporary checking
     * where the cells would get modified.
     */
    protected int tempCells[][];

    /**
     * The game type that this board represents.
     */
    protected int gameType;

    /**
     * Accessor method.
     *
     * @return - the gametype
     */
    public int getGameType() {
        return gameType;
    }

    /**
     * Representation for a blank spot.
     */
    public static final int BLANK = 1;

    /**
     * Representation for a Light side player spot.
     */
    public static final int LIGHT = 3;

    /**
     * Representation for a Dark side player spot.
     */
    public static final int DARK = 5;

    /**
     * Representation for a tie game.
     */
    public static final int TIE = 7;

    protected int pieceSelected;

    public int getPieceSelected() {
        return pieceSelected;
    }

    protected Dimension selection;

    public Dimension getSelection() {
        return selection;
    }

    protected boolean moveInProgress;


    /**
     * Accessor method.
     *
     * @return - the value of the row and column
     * @shyam  the row of the grid
     * @shyam  the column of the grid
     */
    public int getCell(int row, int col) {
        return cells[row][col];
    }

    /**
     * Accessor method
     *
     * @return - the private instance variable to use by other classes
     */
    public int[][] getTempCells() {
        return tempCells;
    }

    /**
     * The value for the current player turn.
     */
    protected int turn;

    /**
     * Accessor method.
     *
     * @return - whose turn it is
     */
    public int getTurn() {
        return turn;
    }

    /**
     * Mutator method.
     *
     * @shyam inTurn - set whose turn it is
     */
    public void setTurn(int inTurn) {
        turn = inTurn;
    }


    /**
     * Abstract method - the plugin will reset the board
     */
    public abstract void resetBoard();


    public abstract boolean moveSequence(Dimension move);


    public abstract int checkWinner();

    //public abstract Ram11FwGameBoard clone();


    public abstract void noLegitMoves();

    public  void draw(GraphicsContext gc){

    }

}

