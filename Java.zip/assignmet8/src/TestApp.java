import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.util.ArrayList;

/**
 * this is the test class
 * @author Rawan Genina, 000747273
 */
public class TestApp extends Application {
    // TODO: Instance Variables for View Components and Model
    private MouseEvent mm;
    /**
     * Graphics context*
     */
    private GraphicsContext gc;
    /**
     * circle
     */
    private Circle circl;
    /**
     * rectangle shape team
     */
    private Rectangle rectan;
    /**
     * array list contins Geomatrics objects (circl )
     */
    private ArrayList<GeometricObject> shape = new ArrayList<>();

    //Buttons and textfields should be added

    Button Circel  = new Button("Cir");
    Button Rectangle = new Button("Rec");


    ChoiceBox<Color> outlineChoice = new ChoiceBox<>();
    ChoiceBox<Color> fillChoice = new ChoiceBox<>();

    // TODO: Private Event Handlers and Helper Methods


    private void CircleHandler(ActionEvent e) {
        System.out.println("Pressed " + mm.getButton() + " at (" + mm.getX() + "," + mm.getY() + ").");
        circl = new Circle(mm.getX(), mm.getY(), 55, Color.BLACK);

        gc.setFill(circl.getFill());
        gc.fillOval(79, 85, 20, 20);
        shape.add(circl);
    }

    private void RectangleHandler(MouseEvent me) {
        System.out.println("Pressed " + me.getButton() + " at (" + me.getX() + "," + me.getY() + ").");
        rectan = new Rectangle(me.getX(), me.getY(), Color.YELLOW, 20);
        rectan.draw(gc);
        shape.add(rectan);
    }


    /**
     * This is where you create your components and the model and add event
     * handlers.
     *
     * @param stage The main stage
     * @throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        Pane root = new Pane();
        Scene scene = new Scene(root, 1000, 600); // set the size here
        stage.setTitle("Assignment 8"); // set the window title here
        stage.setScene(scene);
        // TODO: Add your GUI-building code here

        // 1. Create the model
        // 2. Create the GUI components
        Canvas c = new Canvas(scene.getWidth(), 580);

        // 3. Add components to the root
        root.getChildren().addAll(c, circl, Rectangle);

        // 4. Configure the components (colors, fonts, size, location)
        circl.relocate(50, 800);
        circl.setPrefWidth(200);

        Rectangle.relocate(300, 700);
        Rectangle.setPrefWidth(100);



        GraphicsContext gc = c.getGraphicsContext2D();
        gc.setFill(Color.YELLOW);
        gc.fillRect(0, 0, c.getWidth(), c.getHeight());

        // 5. Add Event Handlers and do final setup
        circl.setOnAction(this::CircleHandler);
        Rectangle.setOnAction(this::RectangleHandler);
        c.addEventHandler(MouseEvent.MOUSE_RELEASED, this::RectangleHandler);


        // 6. Show the stage
        stage.show();
    }

    private void RectangleHandler(ActionEvent event) {
    }


    /**
     * @param args
     */
    public static void main(String[] args) {
    }


}
