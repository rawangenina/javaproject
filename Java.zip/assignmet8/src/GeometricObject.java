import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * GeomatricObject class
 *
 * @author Rawan Genina, 000747273
 */
public class GeometricObject {
    /**
     * x class value of geomatricobject
     */
    private double x;
    /**
     *y class value of geomatricobject
     */
    private double y;
    /**
     * color fill of geomatricobject
     */
    private Color fillcolor;

    /**
     * Constructor that have x, y nd color parameters
     *
     * @param x
     * @param  y
     * @param fillcolor
     */
    public  GeometricObject(double x, double y, Color fillcolor){
        this.x = x;
        this.y = y;
        this.fillcolor = fillcolor;
    }

    /**
     * x value of object
     */
    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    /**
     * y value of object *
     */
    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    /**
     * Color of object
     */
    public Color getFillColor() {
        return fillcolor;
    }

    /**
     *
     * @param fillColor
     */
    public void setFillColor(Color fillColor) {
        this.fillcolor = fillcolor;
    }

    /**
     * Draw Method for the geomatricobject
     *
     * @param  gc
     */
    public  void draw(GraphicsContext gc){

    }


}
