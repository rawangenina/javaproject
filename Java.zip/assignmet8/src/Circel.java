import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Circle Class inherits from Geometric object class
 * the first player team
 * @author  Rawan Genina, 000747273
 */
public class Circel extends GeometricObject {

    private double radius;

    /**
     * constructors for Circle Class
     *
     * @param x
     * @param y
     * @param fillcolor
     * @param radius
     */

    public Circel(double x, double y, Color fillcolor, double radius ){
        super(x, y, fillcolor);
        this.radius = radius;
    }

    /**
     *The getter for the Circle class
     * @return Radius
     */
    public double getRadius() {
        return radius;
    }

    /**
     * The getter for the Circle class
     * @return radius
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * draw method for the circle class
     *
     * @param gc
     */

    @Override
    public void draw(GraphicsContext gc) {
        gc.setFill(getFillColor());
        gc.fillOval(getX() - radius, getY() - radius, radius * 2, radius * 2);
        gc.strokeOval(getX() - radius, getY() - radius, radius * 2, radius * 2);
    }
}

