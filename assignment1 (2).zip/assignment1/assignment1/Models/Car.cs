﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace assignment1.Models
{
    public class Car
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Make { get; set; }
        [Required]
        public string Model  { get; set; }
        [Required]
        public string Color { get; set; }
        public int  Year { get; set; }

        [DisplayName("Purchase Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? PurchaseDate { get; set; }
        [Range(0, 999999)]
        [DisplayFormat(DataFormatString = "{0:N2}")]
        public int  Kilometers { get; set; }
    }
}
