﻿using assignment1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace assignment1.Date
{
    public class SqliteDbContext : DbContext
    {
        public SqliteDbContext()
        {

        }
        public SqliteDbContext(DbContextOptions<SqliteDbContext> options) : base(options)
        {
            
        }
        public virtual DbSet<Car> cars { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           // optionsBuilder.UseSqlite("Filename=./Cars.sqlite");
        }
    }
}
